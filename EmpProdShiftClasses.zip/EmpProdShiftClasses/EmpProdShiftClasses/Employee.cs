﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpProdShiftClasses
{
    class Employee
    {
        //declare variables
        private double _empNumber;
        private string _empName;

        //constructor
        public Employee()
        {
            _empNumber = 0;
            _empName = "";
        }//end constructor



        //_empNumber get and set
        public double employeeNumber
        {          
            set { _empNumber = value; }
            get { return _empNumber; }

        }//end employeeNumber 



        //_empNumber get and set
        public string employeeName
        {
            set { _empName = value; }
            get { return _empName; }

        }//end employeeNumber
        
    }//end employee class





}//end namespace

