﻿/*
 *leigha brown
 * 11-4-17
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpProdShiftClasses
{
    class ShiftSupervisor : Employee
    {
        
        
        //declare variables
        private double _annualSalary;
        private double _annualProdBonus;

        //constructor
        public ShiftSupervisor()
        {
            _annualSalary = 0.00;
            _annualProdBonus = 0.00;
        }

        //set and get for annualSalary
        public double AnnualSalary
        {
            set { _annualSalary = value; }
            get { return _annualSalary;  }
        }


        //set and get for annualProdBonus
        public double AnnualProductionBonus
        {
            set { _annualProdBonus = value; }
            get { return _annualProdBonus; }
        }

    }
}
