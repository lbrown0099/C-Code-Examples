﻿/*
 *leigha brown
 * 11-4-17
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpProdShiftClasses
{
    class ProductionWorker : Employee
    {
        //declare variables
        private double _shiftNumber;
        private double _hourlyPayRate;

        //constructor
        public ProductionWorker()
        {
            _shiftNumber = 0;
            _hourlyPayRate = 0.00;
        }

        //set and get for shiftNumber
        public double shiftNumber
        {
            set { _shiftNumber = value; }
            get { return _shiftNumber;  }
        }


        //set and get for _hourlyPayRate
        public double hourlyPayRate
        {
            set { _hourlyPayRate = value; }
            get { return _hourlyPayRate; }
        }


    }//end class
}//end namespace
