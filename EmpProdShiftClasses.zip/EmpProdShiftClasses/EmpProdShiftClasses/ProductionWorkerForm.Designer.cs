﻿namespace EmpProdShiftClasses
{
    partial class ProductionWorkerApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEmpNum = new System.Windows.Forms.TextBox();
            this.txtEmpName = new System.Windows.Forms.TextBox();
            this.txtShiftNum = new System.Windows.Forms.TextBox();
            this.txtHPR = new System.Windows.Forms.TextBox();
            this.btnCreateObject = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radSS = new System.Windows.Forms.RadioButton();
            this.radPW = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAnnualSal = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtAPB = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(156, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "EnterEmployee Data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employee Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Employee Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Shift Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(52, 303);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Hourly Pay Rate";
            // 
            // txtEmpNum
            // 
            this.txtEmpNum.Location = new System.Drawing.Point(320, 156);
            this.txtEmpNum.Name = "txtEmpNum";
            this.txtEmpNum.Size = new System.Drawing.Size(100, 20);
            this.txtEmpNum.TabIndex = 5;
            // 
            // txtEmpName
            // 
            this.txtEmpName.Location = new System.Drawing.Point(320, 199);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.Size = new System.Drawing.Size(100, 20);
            this.txtEmpName.TabIndex = 6;
            // 
            // txtShiftNum
            // 
            this.txtShiftNum.Location = new System.Drawing.Point(320, 247);
            this.txtShiftNum.Name = "txtShiftNum";
            this.txtShiftNum.Size = new System.Drawing.Size(100, 20);
            this.txtShiftNum.TabIndex = 7;
            // 
            // txtHPR
            // 
            this.txtHPR.Location = new System.Drawing.Point(320, 298);
            this.txtHPR.Name = "txtHPR";
            this.txtHPR.Size = new System.Drawing.Size(100, 20);
            this.txtHPR.TabIndex = 8;
            // 
            // btnCreateObject
            // 
            this.btnCreateObject.Location = new System.Drawing.Point(180, 508);
            this.btnCreateObject.Name = "btnCreateObject";
            this.btnCreateObject.Size = new System.Drawing.Size(105, 35);
            this.btnCreateObject.TabIndex = 14;
            this.btnCreateObject.Text = "Create Object";
            this.btnCreateObject.UseVisualStyleBackColor = true;
            this.btnCreateObject.Click += new System.EventHandler(this.btnCreateObject_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(52, 262);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(212, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "[Enter 1 for day shift or 2 for night shift]";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.radSS);
            this.groupBox1.Controls.Add(this.radPW);
            this.groupBox1.Location = new System.Drawing.Point(55, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(365, 51);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Type";
            // 
            // radSS
            // 
            this.radSS.AutoSize = true;
            this.radSS.Location = new System.Drawing.Point(214, 19);
            this.radSS.Name = "radSS";
            this.radSS.Size = new System.Drawing.Size(110, 19);
            this.radSS.TabIndex = 1;
            this.radSS.TabStop = true;
            this.radSS.Text = "Shift Supervisor";
            this.radSS.UseVisualStyleBackColor = true;
            // 
            // radPW
            // 
            this.radPW.AutoSize = true;
            this.radPW.Checked = true;
            this.radPW.Location = new System.Drawing.Point(61, 19);
            this.radPW.Name = "radPW";
            this.radPW.Size = new System.Drawing.Size(126, 19);
            this.radPW.TabIndex = 0;
            this.radPW.TabStop = true;
            this.radPW.Text = "Production Worker";
            this.radPW.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 349);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "Annual Salary";
            // 
            // txtAnnualSal
            // 
            this.txtAnnualSal.Location = new System.Drawing.Point(320, 349);
            this.txtAnnualSal.Name = "txtAnnualSal";
            this.txtAnnualSal.Size = new System.Drawing.Size(100, 20);
            this.txtAnnualSal.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(52, 399);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(145, 15);
            this.label8.TabIndex = 19;
            this.label8.Text = "Annual Production Bonus";
            // 
            // txtAPB
            // 
            this.txtAPB.Location = new System.Drawing.Point(320, 399);
            this.txtAPB.Name = "txtAPB";
            this.txtAPB.Size = new System.Drawing.Size(100, 20);
            this.txtAPB.TabIndex = 20;
            // 
            // ProductionWorkerApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(499, 579);
            this.Controls.Add(this.txtAPB);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtAnnualSal);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnCreateObject);
            this.Controls.Add(this.txtHPR);
            this.Controls.Add(this.txtShiftNum);
            this.Controls.Add(this.txtEmpName);
            this.Controls.Add(this.txtEmpNum);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ProductionWorkerApp";
            this.Text = "ProductionWorkerApp";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEmpNum;
        private System.Windows.Forms.TextBox txtEmpName;
        private System.Windows.Forms.TextBox txtShiftNum;
        private System.Windows.Forms.TextBox txtHPR;
        private System.Windows.Forms.Button btnCreateObject;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAnnualSal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtAPB;
        private System.Windows.Forms.RadioButton radSS;
        private System.Windows.Forms.RadioButton radPW;
    }
}

