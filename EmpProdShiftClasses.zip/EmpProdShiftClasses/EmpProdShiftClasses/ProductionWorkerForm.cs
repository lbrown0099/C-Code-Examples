﻿/*
 *leigha brown
 * 11-4-17
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpProdShiftClasses
{
    public partial class ProductionWorkerApp : Form
    {
        public ProductionWorkerApp()
        {
            InitializeComponent();
        }

        private void btnCreateObject_Click(object sender, EventArgs e)
        {
            if (radPW.Checked)
            { 
                //create instance of production worker class
                ProductionWorker pw = new ProductionWorker();

            //set number
            pw.employeeNumber = Convert.ToDouble(txtEmpNum.Text);

            //set name
            pw.employeeName = txtEmpName.Text;

            //set shift number
            pw.shiftNumber = Convert.ToDouble(txtShiftNum.Text);

            //set hourly pay rate
            pw.hourlyPayRate = Convert.ToDouble(txtHPR.Text);

            //show data
            MessageBox.Show(pw.employeeName + " has an id number of " + pw.employeeNumber +
                " works shift number " + pw.shiftNumber + " and has an hourly pay rate of " +
                pw.hourlyPayRate);
            }//end if

            else //supervisor checked
            {
                //create instance of Staff class
                ShiftSupervisor ss = new ShiftSupervisor();

                //set number
                ss.employeeNumber = Convert.ToDouble(txtEmpNum.Text);

                //set name
               ss.employeeName = txtEmpName.Text;

                //set AnnualSalary
                ss.AnnualSalary = Convert.ToDouble(txtAnnualSal.Text);

                //set AnnualProductionBonus
                ss.AnnualProductionBonus = Convert.ToDouble(txtAPB.Text);

                //show data
                MessageBox.Show(ss.employeeName + " has an id number of " + ss.employeeNumber +
                    ", has an annual salary of " + ss.AnnualSalary + " and has an annual production bonus of " +
                      ss.AnnualProductionBonus);


            }//end else
        


        }//end btn create object





    }//end class


}//end namespace
