package com.example.leigh.piano;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

public class Piano extends AppCompatActivity {

    Button g5, f5, f4, f3, a3;

    private SoundPool soundPool;
    private int sound_g5, sound_f5, sound_f4, sound_f3, sound_a3;

    public Piano(SoundPool soundPool) {
        this.soundPool = soundPool;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piano);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);





        g5 = (Button) findViewById(R.id.g5);
        f5 = (Button) findViewById(R.id.f5);
        f4 = (Button) findViewById(R.id.f4);
        f3 = (Button) findViewById(R.id.f3);
        a3 = (Button) findViewById(R.id.a3);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = new SoundPool.Builder().setMaxStreams(5).build();
        }

        else {
            soundPool = new SoundPool(5,AudioManager.STREAM_MUSIC, 0);
        }

        sound_g5 = soundPool.load(this, R.raw.g5, 1);
        sound_f5 = soundPool.load(this, R.raw.f5, 1);
        sound_f4 = soundPool.load(this, R.raw.f4, 1);
        sound_f3 = soundPool.load(this, R.raw.f3, 1);
        sound_a3 = soundPool.load(this, R.raw.a3, 1);


        g5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                soundPool.play(sound_g5, 1, 1, 0,0,1);

            }
        });

        f5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                soundPool.play(sound_f5, 1, 1, 0,0,1);

            }
        });

        f4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                soundPool.play(sound_f4, 1, 1, 0,0,1);

            }
        });

        f3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                soundPool.play(sound_f3, 1, 1, 0,0,1);

            }
        });

        a3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                soundPool.play(sound_a3, 1, 1, 0,0,1);

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_piano, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
