﻿namespace WindowsFormsApp1
{
    partial class PigLatinCh8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTranslate = new System.Windows.Forms.Button();
            this.lblEnterEnglish = new System.Windows.Forms.Label();
            this.txtbxEnterEnglish = new System.Windows.Forms.TextBox();
            this.txtBxConvertedSen = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnTranslate
            // 
            this.btnTranslate.Location = new System.Drawing.Point(165, 111);
            this.btnTranslate.Name = "btnTranslate";
            this.btnTranslate.Size = new System.Drawing.Size(97, 31);
            this.btnTranslate.TabIndex = 0;
            this.btnTranslate.Text = "Translate";
            this.btnTranslate.UseVisualStyleBackColor = true;
            this.btnTranslate.Click += new System.EventHandler(this.btnTranslate_Click);
            // 
            // lblEnterEnglish
            // 
            this.lblEnterEnglish.Location = new System.Drawing.Point(106, 26);
            this.lblEnterEnglish.Name = "lblEnterEnglish";
            this.lblEnterEnglish.Size = new System.Drawing.Size(217, 32);
            this.lblEnterEnglish.TabIndex = 1;
            this.lblEnterEnglish.Text = "Type a sentence, then press translate";
            // 
            // txtbxEnterEnglish
            // 
            this.txtbxEnterEnglish.Location = new System.Drawing.Point(64, 61);
            this.txtbxEnterEnglish.Name = "txtbxEnterEnglish";
            this.txtbxEnterEnglish.Size = new System.Drawing.Size(293, 20);
            this.txtbxEnterEnglish.TabIndex = 2;
            // 
            // txtBxConvertedSen
            // 
            this.txtBxConvertedSen.Location = new System.Drawing.Point(64, 179);
            this.txtBxConvertedSen.Name = "txtBxConvertedSen";
            this.txtBxConvertedSen.Size = new System.Drawing.Size(293, 20);
            this.txtBxConvertedSen.TabIndex = 3;
            // 
            // PigLatinCh8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 281);
            this.Controls.Add(this.txtBxConvertedSen);
            this.Controls.Add(this.txtbxEnterEnglish);
            this.Controls.Add(this.lblEnterEnglish);
            this.Controls.Add(this.btnTranslate);
            this.Name = "PigLatinCh8";
            this.Text = "Pig Latin Translator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTranslate;
        private System.Windows.Forms.Label lblEnterEnglish;
        private System.Windows.Forms.TextBox txtbxEnterEnglish;
        private System.Windows.Forms.TextBox txtBxConvertedSen;
    }
}

