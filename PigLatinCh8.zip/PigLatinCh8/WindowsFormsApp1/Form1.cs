﻿/*
 * Leigh Brown
 * 10/25/17
 * This app translates between english and pig latin
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class PigLatinCh8 : Form
    {
        public PigLatinCh8()
        {
            InitializeComponent();
        }

        
        



        private void btnTranslate_Click(object sender, EventArgs e)
        {
            //the ReturnPG method accepts a sentence as a argument and returns the sentence
            //translated into pig latin
            string strPigLatinWord = ConvertToPG(txtbxEnterEnglish.Text);

            //assign PG word to the text box
            txtBxConvertedSen.Text = strPigLatinWord;
        }


        //sentence converter method
        private string ConvertToPG(string english)
        {
            //declare variables
            string pg = string.Empty;
            string firstL = string.Empty;
            string space = " ";
            string exLetter = string.Empty;

            //position of letter
            int pos = 0;

            //split string by spaces
            string[] englishWord = english.Split();
            foreach (string word in englishWord)
            {
                //keep the letters from the input string
                if(pos !=0)
                {
                    pg = pg + space;

                }

                else
                {
                    pos = 1;
                }

                //get the first letter of the word
                firstL = word.Substring(0, 1);

                //get the rest of the characters after the word
                exLetter = word.Substring(1, word.Length - 1);

                //translate into Pig Latin
                pg = pg + exLetter + firstL + "ay";
                   
            }//end for each

            return pg.ToString();
        }//end convertToPG method

    }//end class
}//end name space
