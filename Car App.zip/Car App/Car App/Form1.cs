﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //car object
        Car car = new Car(1992, "honda");
        
  

        //add 5 to the cars current speed
        private void btnAcc_Click(object sender, EventArgs e)
        {
            car.Accelerate();

            //update speed text box 
            txtSpeed.Text = car.Speed.ToString("0");
        }//end btnAcc



        //subtract 5 from the cars current speed if speed is above 0
        private void btnBrake_Click(object sender, EventArgs e)
        {
            //check if speed is above 0
            if (car.Speed == 0)
            {
                MessageBox.Show("Invalid Speed");
            }
            else
            {
                car.Break();

                //update speed text box 
                txtSpeed.Text = car.Speed.ToString("0");
            }        
        }//end btnBreak

        private void btnShowCarInfo_Click(object sender, EventArgs e)
        {
            //create instance of CarForm2 class
            CarForm2 secondForm = new CarForm2();

         
            //display car year in year text box 
            secondForm.txtYear.Text = car.Year.ToString();

            //display car make in make text box 
            secondForm.txtMake.Text = car.Make.ToString();

            //show CarForm2
            secondForm.ShowDialog();
        }
    }//end class
}//end namespace
