﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_App
{
    public partial class CarForm2 : Form
    {
        public CarForm2()
        {
            InitializeComponent();
        }

        private void CarForm2_Load(object sender, EventArgs e)
        {
           

        }
    }
}
